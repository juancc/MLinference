from MLinference.strategies.Cascade import Cascade
from MLinference.strategies.Multi import Multi
from MLinference.strategies.Posterior import Posterior