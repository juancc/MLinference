from MLcommon.AbcModel import AbcModel
from MLcommon.InferenceModel import InferenceModel
