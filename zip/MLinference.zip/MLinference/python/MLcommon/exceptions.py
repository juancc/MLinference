"""Library Exceptions"""

# Error for wrong value - missing parameter in config files
class ConfigParamError(Exception): pass
